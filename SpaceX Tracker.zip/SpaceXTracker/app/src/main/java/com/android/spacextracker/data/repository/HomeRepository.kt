package com.android.spacextracker.data.repository

import com.android.spacextracker.data.api.ApiInterface
import com.android.spacextracker.domain.GetSpaceXLaunchesRes
import com.android.spacextracker.domain.SpaceXLaunchesResItem
import retrofit2.Call
import retrofit2.Response
import javax.inject.Inject

class HomeRepository @Inject constructor(private val apiInterface: ApiInterface) {

    suspend fun getSpaceXLaunchesApi(): Call<GetSpaceXLaunchesRes> =
        apiInterface.getSpaceXLaunches()
}
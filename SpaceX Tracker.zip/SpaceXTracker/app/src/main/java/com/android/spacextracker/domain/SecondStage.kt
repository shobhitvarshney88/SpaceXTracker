package com.android.spacextracker.domain

data class SecondStage(
    val block: Int,
    val payloads: List<Payload>
)
package com.android.spacextracker.domain

data class LaunchFailureDetails(
    val altitude: Int,
    val reason: String,
    val time: Int
)
package com.android.spacextracker.domain

data class FirstStage(
    val cores: List<Core>
)
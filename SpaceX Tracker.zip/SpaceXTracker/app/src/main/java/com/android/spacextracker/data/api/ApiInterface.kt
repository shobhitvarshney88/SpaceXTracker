package com.android.spacextracker.data.api

import com.android.spacextracker.domain.GetSpaceXLaunchesRes
import com.android.spacextracker.domain.SpaceXLaunchesResItem
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET

interface ApiInterface {

    @GET("launches")
    fun getSpaceXLaunches(): Call<GetSpaceXLaunchesRes>

}
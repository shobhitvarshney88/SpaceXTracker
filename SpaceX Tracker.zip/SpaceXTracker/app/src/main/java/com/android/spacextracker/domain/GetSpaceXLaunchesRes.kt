package com.android.spacextracker.domain

class GetSpaceXLaunchesRes : ArrayList<SpaceXLaunchesResItem>()
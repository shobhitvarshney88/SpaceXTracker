package com.android.spacextracker.domain

data class Telemetry(
    val flight_club: String
)
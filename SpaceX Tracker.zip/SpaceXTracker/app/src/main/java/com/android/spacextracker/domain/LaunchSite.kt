package com.android.spacextracker.domain

data class LaunchSite(
    val site_id: String,
    val site_name: String,
    val site_name_long: String
)